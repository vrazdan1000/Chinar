const express = require('express')
const bodyParser = require('body-parser')

const http = require('http')
const fs = require('fs')

const app = express()

app.use(express.static('public'));
app.set('view engine', 'ejs')

const server = app.listen(3000)

app.use(bodyParser.urlencoded({
    extended: true
}));

app.use(bodyParser.json());
var jsonParser = bodyParser.json()

const urlencodedParser = bodyParser.urlencoded({extended:true})

app.get('/', (req,res) => {
    res.render('index')
})

app.get('/createmenu', (req,res) => {
    res.render('createmenu')
})

app.get('/home', (req,res) => {
    res.render('index')
})

app.get('/about', (req,res) => {
    res.render('about')
})

app.get('/contact', (req,res) => {
    res.render('contact')
})

app.get('/menu', (req,res) => {
    fs.readFile('./docs/vikram.json', "utf-8", (err, datajson) => {
        if(err) {
            console.log('error')
        }

        const itemsArray = JSON.parse(datajson);
        const counter = itemsArray.length
        res.render('menu', {data: itemsArray, counter: counter})
    })        
})

app.post('/order', urlencodedParser, (req,res) => {
    fs.readFile("./docs/orders.json", (err, buffer) => {
        if (err) return console.error('File read error: ', err)
      
        const data = JSON.parse(buffer)
        data.push(JSON.parse(JSON.stringify(req.body)))
        console.log("New Data",data)
        console.log("writing file")

        fs.writeFile("./docs/orders.json", JSON.stringify(data), err => {
            if (err) return console.error('File write error:', err)
          })          
      })
      console.log('Redirect')
      res.render('about')
})

app.post('/createmenu', urlencodedParser, (req,res) => {

    fs.readFile("./docs/vikram.json", (err, buffer) => {
        if (err) return console.error('File read error: ', err)
      
        const data = JSON.parse(buffer)
      
        data.push(JSON.parse(JSON.stringify(req.body)))
        console.log("New Data",data)

        fs.writeFile("./docs/vikram.json", JSON.stringify(data), err => {
            if (err) return console.error('File write error:', err)
            res.redirect('menu')
          })
      })
})

app.use((req,res) => {
    res.render('404')
})