const { request, response } = require('express')
const express = require('express')
const app = express()
const fs = require('fs');
const bodyParser = require('body-parser')
const mongoose = require('mongoose')
const Menu = require('./models/menu')
const Order = require('./models/order');
const { db } = require('./models/menu');
const MongoClient = require('mongodb').MongoClient;


app.use(bodyParser.urlencoded({
    extended: true
}));

// for reading the data being sent into the ejson file through HTTP
app.use(bodyParser.json());
var jsonParser = bodyParser.json()

const urlencodedParser = bodyParser.urlencoded({extended:true})

//use the express.static middleware to make it possible to access files from this folder(public) via HTTP.

app.use(express.static('public'))

app.set('view engine','ejs')

const dbURI = 'mongodb+srv://vin:pass@cluster0.0dwmtpo.mongodb.net/note-tuts?retryWrites=true&w=majority'
mongoose.set('strictQuery', false)
mongoose.connect(dbURI,{useNewUrlParser: true, useUnifiedTopology: true })
    .then((result)=> 
        {
            app.listen(3000);
            console.log ('Connected to DB');
        })
    .catch((err) => console.log(err))

   
    
//registers a route handler that Express will call when it receives an HTTP GET request to /test.
app.get('/',(req,res) => {
    //part of the request and response cycle to send data from the server to the client-side through HTTP requests.
    res.set('content-type','text/html')
    res.render('index') // sends the HTTP response. The body parameter can be a String or a Buffer object or an object or an Array.
})

app.delete('/deletemenu/:id', (req, res) => {
    console.log('Inside Delete')
    Menu.findByIdAndDelete({_id: req.params.id})
        .then((result) => {
            res.send('<h1>Inside Delete</h1>')
        })
        .catch((err) => {
            console.log(err)
        })

})    

app.get('/menu',(req,res) => {

    // fs.readFile('./db/menu.json', 'utf8', (err, data) => {
    //     if (err) {
    //       console.error(err);
    //       return;
    //     }
    //     const responsedata = JSON.parse(data)
    //     res.set('content-type','text/html')
    //     res.render('menu',{data:responsedata})
    //   });

    Menu.find()
            .then((result) => {
                res.render('menu',{ data: result })
            })
            .catch((err) => {
                console.log(err)
            })
})

app.get('/createmenu',(req,res) => {
    // fs.readFile('./db/menu.json', 'utf8', (err, data) => {
    //     if (err) {
    //       console.error(err);
    //       return;
    //     }
    //     const responsedata = JSON.parse(data)
    Menu.find()
    .then((result) => {
        res.render('managemenu',{ data: result })
    })
    .catch((err) => {
        console.log(err)
    })
        // res.set('content-type','text/html')
        // res.render('managemenu',{data:responsedata})
      });
    


app.get('/login',(req,res) => {
    res.set('content-type','text/html')
    res.render('login')
})
//POST is used to send data to a server to create/update a resource.
app.post('/login', function(req, res){
    console.log(req.body.user.user);
    console.log(req.body.user.password);
    if (req.body.user.user == "vin" & req.body.user.password == "pass") {
        res.redirect('/login')
    }
    else{
        res.redirect('/index')
    }
});

app.get('/orders',(req,res) => {

    // fs.readFile('./db/orders.json', 'utf8', (err, data) => {
    //     if (err) {
    //       console.error(err);
    //       return;
    //     }

        
    //     const responsedata = JSON.parse(data)
    //     res.render('orders',{data:responsedata})

    //     res.render('orders',{data:JSON.parse(data)})

        
    // })
    Order.find()
    .then((result) => {
        res.render('orders',{ data: result })
    })
    .catch((err) => {
        console.log(err)
    })
});


//writes the new orders into the order file using HTTP POST method and updates the orders table on the webpage
app.post('/createorder', urlencodedParser, (req,res) => {

    // fs.readFile("./db/orders.json", (err, buffer) => {
    //     if (err) return console.error('File read error: ', err)
      
    //     const data = JSON.parse(buffer)
    //     console.log(req.body)
    //     data.push(JSON.parse(JSON.stringify(req.body)))
    //     fs.writeFile("./db/orders.json", JSON.stringify(data), err => {
    //         if (err) return console.error('File write error:', err)                
    //         res.send('ok')
    //       })
    //   })

    console.log('hello')
    console.log(req.body)
    res.send('ok')
    console.log('shello')
    const order = new Order(req.body);
console.log(req.body);
    order.save()
    .then((result) => {
        res.redirect('/orders')
    })
    .catch((err) => {
        console.log(err);
    });
})


app.post('/createmenu', urlencodedParser, (req,res) => {
    // fs.readFile("./db/menu.json", (err, buffer) => {
    //     if (err) return console.error('File read error: ', err)
      
    //     const data = JSON.parse(buffer)
    //     console.log(req.body)
    //     data.push(JSON.parse(JSON.stringify(req.body)))
    //     fs.writeFile("./db/menu.json", JSON.stringify(data), err => {
    //         if (err) return console.error('File write error:', err)
    //         res.send('ok')
    //       })
    //   })
    const menu = new Menu(req.body);
console.log(req.body);
    menu.save()
    .then((result) => {
        res.redirect('/menu')
    })
    .catch((err) => {
       console.log(err);
    });
})

// app.get('/', async (req, res) => {
//     let data = await dbConnect();
//     data = await data.find().toArray();
//     res.send(data)
// });

// app.post('/', async (req, res) => {
//     let data = await dbConnect();
//     let result = await data.insert(req.body)
//     res.send(result)
// });

// app.put ("/:name", async (req, res) => {
//     const data = await dbConnect();
//     let result = data.updateOne(
//         {name: req.params.name},
//         {$set: req.body}
//     )
//     res.send({ status: "updated" })
// });


app.post('/user/:searchParams', (req,res) => {
    console.log(req.body)
})