const mongoose = require('mongoose');
// will be used to define the structure of the document/data in the collection
const Schema = mongoose.Schema;

const menuSchema = new Schema({
    name: {
        type: String,
       // required: true
    },
    description: {
        type: String,
       // required: true
    },
    price: {
        type: Number,
       // required: true
    }
}, {timestamps: true});

const Menu = mongoose.model('Menu', menuSchema);
module.exports = Menu;