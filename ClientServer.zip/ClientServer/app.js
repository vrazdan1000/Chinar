const { request, response } = require('express')
const express = require('express')
const app = express()
const fs = require('fs');
const bodyParser = require('body-parser')
app.use(bodyParser.urlencoded({
    extended: true
}));

app.use(bodyParser.json());
var jsonParser = bodyParser.json()

const urlencodedParser = bodyParser.urlencoded({extended:true})


app.use(express.static('public'))

app.listen(3000)
app.set('view engine','ejs')

app.get('/',(req,res) => {
    res.set('content-type','text/html')
    res.render('index')
})
app.get('/menu',(req,res) => {
    fs.readFile('./db/menu.json', 'utf8', (err, data) => {
        if (err) {
          console.error(err);
          return;
        }
        const responsedata = JSON.parse(data)
        res.set('content-type','text/html')
        res.render('menu',{data:responsedata})
      });
    
    
})

app.get('/about',(req,res) => {
    res.set('content-type','text/html')
    res.render('about')
})
app.get('/orders',(req,res) => {

    fs.readFile('./db/orders.json', 'utf8', (err, data) => {
        if (err) {
          console.error(err);
          return;
        }

        
        const responsedata = JSON.parse(data)
        res.render('orders',{data:responsedata})
        
    })

});

app.post('/createorder', urlencodedParser, (req,res) => {
    fs.readFile("./db/orders.json", (err, buffer) => {
        if (err) return console.error('File read error: ', err)
      
        const data = JSON.parse(buffer)
        console.log(req.body)
        data.push(JSON.parse(JSON.stringify(req.body)))
        fs.writeFile("./db/orders.json", JSON.stringify(data), err => {
            if (err) return console.error('File write error:', err)
            res.send('ok')
          })
      })
})