const { request, response } = require('express')
const express = require('express')
const session = require('express-session');

const app = express()
const fs = require('fs');
const bodyParser = require('body-parser')
const mongoose = require('mongoose')
const Menu = require('./models/menu')
const Order = require('./models/order');
const { db } = require('./models/menu');
const User = require('./models/user');

const MongoClient = require('mongodb').MongoClient;

app.use(session({
	secret: 'secret',
	resave: true,
	saveUninitialized: true
}));

app.use(bodyParser.urlencoded({
    extended: true
}));

// for reading the data being sent into the ejson file through HTTP
app.use(bodyParser.json());
var jsonParser = bodyParser.json()

const urlencodedParser = bodyParser.urlencoded({extended:true})

//use the express.static middleware to make it possible to access files from this folder(public) via HTTP.

app.use(express.static('public'))

app.set('view engine','ejs')

const dbURI = 'mongodb+srv://vin:pass@cluster0.0dwmtpo.mongodb.net/note-tuts?retryWrites=true&w=majority'
mongoose.set('strictQuery', false)
mongoose.connect(dbURI,{useNewUrlParser: true, useUnifiedTopology: true })
    .then((result)=> 
        {
            app.listen(3000);
            console.log ('Connected to DB');
        })
    .catch((err) => console.log(err))

   
    
//registers a route handler that Express will call when it receives an HTTP GET request to /test.
app.get('/',(req,res) => {
    req.session.destroy();
    req.loggedin = false;
    req.username = "";
    //part of the request and response cycle to send data from the server to the client-side through HTTP requests.
    res.set('content-type','text/html')
    res.render('index') // sends the HTTP response. The body parameter can be a String or a Buffer object or an object or an Array.
})

app.delete('/deletemenu/:id', (req, res) => {
    if (req.session.loggedin) {
        Menu.findByIdAndDelete({_id: req.params.id})
        .then((result) => {
            res.send('<h1>Inside Delete</h1>')
        })
        .catch((err) => {
            console.log(err)
        })    
	} else {
		// Not logged in
        res.set('content-type','text/html')
		res.send('<center><b><p>Please login to view this page!</p></b></center>');	}
})    

app.get('/menu',(req,res) => {
	if (req.session.loggedin) {
        Menu.find()
                .then((result) => {
                    res.render('menu',{ data: result })
                })
                .catch((err) => {
                    console.log(err)
                })    
	} else {
		// Not logged in
        res.set('content-type','text/html')
		res.send('<center><b><p>Please login to view this page!</p></b></center>');
	}


});

app.get('/createmenu',(req,res) => {
	if (req.session.loggedin) {
        Menu.find()
        .then((result) => {
            res.render('managemenu',{ data: result })
        })
        .catch((err) => {
            console.log(err)
        })        
	} else {
		// Not logged in
        res.set('content-type','text/html')
		res.send('<center><b><p>Please login to view this page!</p></b></center>');	}
  
});

app.get('/login',(req,res) => {
	if (req.session.loggedin) {
        res.set('content-type','text/html')
        res.render('login')    
	} else {
		// Not logged in
        res.set('content-type','text/html')
		res.send('<center><b><p>Please login to view this page!</p></b></center>');	}
	res.end();
})

//POST is used to send data to a server to create/update a resource.
app.post('/login', function(req, res){
    console.log(req.body.userName);
    console.log(req.body.userPassword);
	let username = req.body.userName;
	let password = req.body.userPassword;

    User.findOne({userid: username}, function(error, foundUser) {
        if(!error) {
            console.log('No Error');
            if (foundUser) {
                console.log('Found User');
                //----compare passwords-----//
             if (foundUser.password==password){ //password matches
                   req.session.loggedin = true;
                   req.session.userid = username;
                   res.redirect('/login')
               }else{
                    res.redirect('/index')

               }
          //---end checking password compraison
            } else {
                res.send("<CENTER>Invalid Credentials. <br> <a href='/'>Try Again</a></CENTER>");
            }
        } else {
            res.send(error);
        }
    })
});

app.get('/orders',(req,res) => {
	if (req.session.loggedin) {
        Order.find()
        .then((result) => {
            res.render('orders',{ data: result })
        })
        .catch((err) => {
            console.log(err)
        })    
	} else {
		// Not logged in
        res.set('content-type','text/html')
		res.send('<center><b><p>Please login to view this page!</p></b></center>');	}
});


//writes the new orders into the order file using HTTP POST method and updates the orders table on the webpage
app.post('/createorder', urlencodedParser, (req,res) => {
	if (req.session.loggedin) {
        res.send('ok')
        const order = new Order(req.body);
        console.log(req.body);
        order.save()
        .then((result) => {
            res.redirect('/orders')
        })
        .catch((err) => {
            console.log(err);
        });   
	} else {
		// Not logged in
        res.set('content-type','text/html')
		res.send('<center><b><p>Please login to view this page!</p></b></center>');	}
})


app.post('/createmenu', urlencodedParser, (req,res) => {
    if (req.session.loggedin) {
        const menu = new Menu(req.body);
        console.log(req.body);
        menu.save()
        .then((result) => {
            res.redirect('/menu')
        })
        .catch((err) => {
           console.log(err);
        });    
	} else {
		// Not logged in
        res.set('content-type','text/html')
		res.send('<center><b><p>Please login to view this page!</p></b></center>');	}
})

app.post('/updatemenu', urlencodedParser, (req,res) => {
    if (req.session.loggedin) {
        console.log('Inside')
        console.log('id', req.body.id)
        const filter = { _id: parseInt(req.body.id)};
        console.log(req.body)
        Menu.findByIdAndUpdate({_id: req.body.id}, {name: req.body.name, description: req.body.description, price: req.body.price})
        .then((result) => {
            res.redirect('menu')
        })
        .catch((err) => {
            console.log(err)
        })
    

        console.log('Done')
	} else {
		// Not logged in
        res.set('content-type','text/html')
		res.send('<center><b><p>Please login to view this page!</p></b></center>');	}
})

app.post('/user/:searchParams', (req,res) => {
    console.log(req.body)
})