const mongoose = require('mongoose')
const Schema = mongoose.Schema;

const orderSchema = new Schema({
    personName: {
        type: String,
        required: true
    },
    personAddress: {
        type:String,
        required: true
    },
    items:[{
        name: {type: String, required: true},
        description: {type: String, required: true},
        price: {type: Number, required: true},
        quantity: {type: Number, required: true},
        }],
    totalOrderCost: {
            type:Number,
            required: true
    }   
}, {timesstamps: true})

const Order = mongoose.model('Order', orderSchema)
module.exports = Order