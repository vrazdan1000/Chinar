const mongoose = require('mongoose');
// will be used to define the structure of the document/data in the collection
const Schema = mongoose.Schema;

const usersSchema = new Schema({
    userid: {
        type: String,
       // required: true
    },
    password: {
        type: String,
       // required: true
    }
}, {timestamps: true});

const User = mongoose.model('users', usersSchema);
module.exports = User;