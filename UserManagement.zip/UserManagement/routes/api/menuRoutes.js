const express = require('express');
const router = express.Router();
const Menu = require('../../models/menu')
const bodyParser = require('body-parser')
const methodOverride = require('method-override');

router.use(express.urlencoded({extended: true}))
router.use(bodyParser.urlencoded({ extended: false }))
router.use(bodyParser.json())
router.use(express.static('public'))

router.get('/add-menu', (req, res) => {
    console.log('Inside Add Menu Get');
    res.render('createmenu');
})

router.put('/:id', (req, res) => {
    console.log('Inside Put');
    console.log(req.params.id);
    console.log(req.body);
    Menu.findByIdAndUpdate({_id: req.params.id}, req.body)
    .then((result) => {
        res.json({"redirect": "/menu"})
    })
    .catch((err) => {
        console.log(err)
    })

})

router.post('/', (req, res) => {
    console.log('Inside Post', req.body)
    const menu = new Menu(req.body)
    menu.save()
     .then((result) => {
        res.json({"redirect": "/menu"})
     })
     .catch((err) => {
         console.log(err);
     })
})

router.get('/', (req, res) => {
    console.log('Inside Get')
    Menu.find()
    .then((result) => {
        res.render('menu', {menus: result})
    })
})

router.get('/:id', (req, res) => {
    console.log('Inside Get by ID')
    Menu.findById(req.params.id)
    .then((result) => {
        res.render('managemenu', {menu: result})
    })
})


router.delete('/:id', (req, res) => {
    console.log('Inside Delete')
    Menu.findByIdAndDelete({_id: req.params.id})
        .then((result) => {
            res.send('<h1>Inside Delete</h1>')
        })
        .catch((err) => {
            console.log(err)
        })

})

module.exports = router;