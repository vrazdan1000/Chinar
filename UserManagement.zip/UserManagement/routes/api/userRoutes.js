const express = require('express');
const router = express.Router();
const User = require('../../models/user')
const bodyParser = require('body-parser')

router.use(express.urlencoded({extended: true}))
router.use(bodyParser.urlencoded({ extended: false }))
router.use(bodyParser.json())

router.get('/', (req, res) => {
    console.log('Inside Get')
    User.find()
    .then((result) => {
        res.render('users', {users: result})
    })
})

router.post('/', (req, res) => {
    console.log('Inside Post', req.body)
    const user = new User(req.body)
    user.save()
     .then((result) => {
        res.send('<h1>User Created Using Post</h1>')
     })
     .catch((err) => {
         console.log(err);
     })
})

router.put('/:id', (req, res) => {
    console.log('Inside Put')
    User.findByIdAndUpdate({_id: req.params.id}, req.body)
        .then((result) => {
            res.send('<h1>Inside Put</h1>')
        })
        .catch((err) => {
            console.log(err)
        })
})

router.delete('/:id', (req, res) => {
    console.log('Inside Delete')
    User.findByIdAndDelete({_id: req.params.id})
        .then((result) => {
            res.send('<h1>Inside Delete</h1>')
        })
        .catch((err) => {
            console.log(err)
        })

})

module.exports = router;