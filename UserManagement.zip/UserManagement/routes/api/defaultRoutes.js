const express = require('express');
const router = express.Router();
const Menu = require('../../models/menu')
const bodyParser = require('body-parser')

router.use(express.urlencoded({extended: true}))
router.use(bodyParser.urlencoded({ extended: false }))
router.use(bodyParser.json())

router.get('/', (req, res) => {
    Menu.find()
    .then((result) => {
        res.render('menu', {menus: result})
    })

})

module.exports = router;