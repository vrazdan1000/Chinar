const express = require('express');
const mongoose = require('mongoose')

const defaultRoutes =  require('./routes/api/defaultRoutes')
const userRoutes =  require('./routes/api/userRoutes')
const menuRoutes =  require('./routes/api/menuRoutes')

const app = express();

const PORT = process.env.PORT || 5000;

const dbURI = 'mongodb+srv://admin:admin@chinar.vdrauc2.mongodb.net/chinardb?retryWrites=true&w=majority'
mongoose.set('strictQuery', false)
mongoose.connect(dbURI,{useNewUrlParser: true, useUnifiedTopology: true })
    .then((result)=> 
        {
            app.listen(PORT, () => console.log('Server started on port ', PORT));
            console.log ('Connected to DB');
        })
    .catch((err) => console.log(err))

app.set('view engine', 'ejs')
app.use(express.static('public'))
app.use('/users', userRoutes)
app.use('/menu', menuRoutes)
app.use('/', defaultRoutes)

